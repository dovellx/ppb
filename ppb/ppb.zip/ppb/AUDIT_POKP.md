# Q8 审计：`verify_poks2` 为什么不调用 `verify_pokp_proof` / `verify_pok_star_recursive`

方法：6 个独立视角对照论文 Alg. 1 / 2 / 3 / 5 逐行审计，每条发现再由独立的"反驳者"
尝试推翻，只保留推翻失败的。下面标注了哪些是我**亲自读代码复核过**的。

---

## 1. 直接回答

**是死代码，但不是"验证器被削弱"。** 这两个函数的签名要求真实验证者永远拿不到的输入：

```rust
fn verify_pok_star_recursive(
    ..., y: &BigUint,                    // src/ppb.rs:2322
    current_c_p: &crate::cs::CsCiphertext,  // src/ppb.rs:2325
    ...)
```

它们只在 [src/ppb.rs:2432-2441](src/ppb.rs#L2432-L2441) 用到这两个入参，做的是**明文多项式求值**：
`e1 = lower.evaluate(y)`、`e3 = upper.evaluate(y)`、`e2 = e3^{y^half}`，再与 `c_p` 比对。
这里的 `y` 就是 `y_id`（`verify_poks2` 把 `proof.c_id` 当作 aux 根，[src/ppb.rs:2643](src/ppb.rs#L2643)）
——**用户的秘密身份**。论文 Alg. 5 的 `V*_P` 既不接受 `y` 也不接受 `cP`；
Def. 1 的 ZK 与 Appx. B 的 Blueprint Hiding 更是明令验证者不得持有 `y_id`。

逐检查 diff 的结果：活路径 [verify_pok_star_public_shell](src/ppb.rs#L2116) 与死版本的
检查集合**完全相同、顺序相同**（base case 2131-2145 vs 2336-2349；递归段五次 `verify_cs_com`、
`verify_cs_add`、aux 查表、两次 `verify_cs_mult`、`verify_df_open_public_scalar`、
第二次 `verify_cs_add`、FS α 重算、τ 追加、公开折叠）。死版本**唯一**多出的就是那段
依赖秘密的明文校验。

**所以：活验证器一个检查都不少，"时间被低估"这条特定担忧不成立。**
死代码只是卫生问题（建议删除或移入 `#[cfg(test)]` 并改名为"见证自洽检查"）。

用 `tau.c_p` 替代外部传入的 `c_p` 也是合法的：`c_p_commitment` 被强制等于
`com_ah_with_zero_randomness(tau.c_p)`（[2263-2270](src/ppb.rs#L2263-L2270)，
该 helper 的 C2=C4=1 ⇒ 承诺随机数恒为 0，值即 `tau.c_p`），且 `tau.c_p` 进入每一轮 α 的哈希。

**但审计在活路径上找到了别的、更严重的问题。**

---

## 2. Alg. 5 / Alg. 2 逐条对照

| 论文条目 | 代码实现 | 状态 |
|---|---|---|
| Alg. 1 L1 `CP ← Com_AH(cP;0)` | `com_ah_with_zero_randomness` src/pok.rs:291 / 验证方重算 src/ppb.rs:2263 | 实现（但导致 **Z2**） |
| Alg. 1 L2 aux 平方链 `C_{y^{2^i}}` | 建链 src/pok.rs:1150-1184 / 验证 src/ppb.rs:2277-2287，强制 `aux.len()==log n` 且 `round==i` | 实现（但缺 Remark 1，见 **Z3**） |
| Alg. 1 L3 `τ=(Cy,c_0..c_{n-1},cP)` | src/pok.rs:1187 / 钉死 `tau.cy`、`tau.c_values`、`tau.history` src/ppb.rs:2250-2260 | 实现（强于论文） |
| Alg. 5 L1-2 base case | `verify_cs_com_ciphertext(CP, c_values[0])` src/ppb.rs:2139 | 实现 |
| Alg. 2 L8 `C1,C2,C3` 良构 | 五次 `verify_cs_com` src/ppb.rs:2151-2155 | **缺失**：`verify_cs_com` 从不读 `c1/c3`（见 **S1**） |
| Alg. 2 L9 `Com_AH(e,r)=CP` | 根层由零随机数固定，深层 `CP := 上一轮 C'_P` src/ppb.rs:2232 | 等价替代 |
| Alg. 2 L10 `e = e1 ⊕ e2` | `verify_cs_add(c1,c2,CP)` src/ppb.rs:2160 | 实现 |
| Alg. 2 L11 `e2 = y^{n/2} ⊙ e3` | aux 查表 src/ppb.rs:2171 + `verify_cs_mult` src/ppb.rs:2176 | 实现，但可被 **S1** 绕过 |
| Alg. 5 L6 `α ← H(C1,C2,C3,τ)` | src/ppb.rs:1995 / 相等性检查在折叠与递归**之前** src/ppb.rs:2215 | 实现 |
| Alg. 5 L7 `c'_i = c_i ⊕ (c_{i+n/2} ⊙ α)` | 验证方自行折叠 src/ppb.rs:2221-2224，`fold` src/pok.rs:146，`split_in_half` src/pok.rs:121 | 实现（方向未反） |
| Alg. 2 L12 `e' = e1 ⊕ (α⊙e3)` | `verify_cs_mult` + `verify_df_open_public_scalar` + `verify_cs_add` src/ppb.rs:2186-2213 | 实现，但可被 **S1** 绕过 |
| Alg. 3 L10 `π_y` 是 NIZK | 只有一次模乘 `c_id·c_at == c_y` src/ppb.rs:2618-2622 | **缺失**（见 **S2**） |
| Fig. D.3 `if r3 = 0 return ⊥` | 只在 prover 侧 src/ppb.rs:1598 / src/hec.rs:331 | **缺失**（见 **S3**） |
| Remark 1 mod-n 归约子证明 | 全仓库无 | **缺失**（见 **Z3**） |
| Fig. F.4 `Com_CS` 基 `g` 由 setup 固定 | 取自 `proof.ah_g` src/ppb.rs:161, 2606 | 规格偏离 |

已排除的"疑似 bug"（复核后确认正确）：折叠方向、α 计算顺序、`verify_cs_mult` 参数序、
aux 下标映射（末层 `half=1` 返回根 `Cy`）、系数向量 1-indexed 的 off-by-one。

---

## 3. 确认的问题

标 ✅ = 我亲自读代码复核过机制；标 ⚠️ = 审计给出可复现 PoC，但我未逐行重跑。

### S1 ⚠️（机制的前提条件 ✅）`verify_cs_com` 不检查承诺的值分量 ⇒ `verify_cs_mult` 可退化

[src/cs_commit.rs:795-826](src/cs_commit.rs#L795-L826) 只对 `commitment.c2` 与 `commitment.c4`
建立方程，**`c1` 和 `c3` 从头到尾没被读过**（我已复核）。于是证明者可以令
`round.c3.c1 = c3.c3 = 0` 仍通过 `verify_cs_com`；而 `verify_cs_mult` 的值方程
`cb.c1^{2z_y}·g^{2z1} =? r1²·ca.c1^{2e}` 在取 `proof.r1 = r3 = n` 时两边同为 0，
对**任意** `ca` 成立。后果：`verify_pokp_public_components` 可以返回一个不等于
`Enc(P(y_id))` 的 `E`；取 `E = Enc(0)` 则 `Z_nf = r3⊙E` 解密为 0，**监控名单闸门完全失效**。

### S2 ✅ `C_y` 只绑定 `y_id + y_at`，求值点可自由平移 ⇒ 名单规避

[map_y_to_df_message](src/ppb.rs#L1460) 返回 `(y_id + y_at) mod n`，`C_y = Com(m_y; r_y)`
是**单基**DF 承诺；验证器对 `π_y` 的全部内容就是
`proof.c_id * proof.c_at == c_y (mod n²)`（[src/ppb.rs:2618-2622](src/ppb.rs#L2618-L2622)）。
论文 Alg. 3 L10 要求的是对 `(y_id, y_at)` **作为一对**的 NIZK。

攻击：名单内用户 `y=(5,7)` 改用 `y'=(6,6)`，`r_y` 不变 ⇒ `C_y` **逐位相同**，
`verify_escrow` 通过，`dec_ppb` 返回 `None`。**名单内用户完整逃逸，且用的是同一个
被凭证签名过的 `C_y`。** 反向亦破坏 non-frameability。
仓库里本来就有可用的向量承诺 [commit_df_vector_with_bases](src/df.rs#L127)，但只用于 S1 系数向量。

### S3 ⚠️（缺失本身 ✅）`r3` 可逆性从未证明 ⇒ `r3 = 0` 绕过 ⊥ 闸门

[src/ppb.rs:2668-2677](src/ppb.rs#L2668-L2677) 只验乘法关系；防护只在 prover 侧。
代码 [2656-2667](src/ppb.rs#L2656-L2667) 自己的注释已承认这个缺口。
PoC 报告：置 `z_nf=(1,1)`、`c_r3=Com(0)`，并取 `r1 = (11-7)·P(7)^{-1} mod n`
（`r1` 无任何约束），可让非名单用户 `y_id=7` 被"解密"成名单成员 `11`，且 **Judge 接受**。

> 论文 Thm 7 的证明本身也有瑕疵："r3 P(y) = 0 ... is only true if y in x since r3 > 0"
> ——在合成模数 `Z_n` 上 `r3 ≠ 0` 并不蕴含 `r3` 可逆。这是**论文与实现共有**的问题。

### Z1 ✅ `Com_AH` 零盲化 ⇒ 审计者能直接解密出**每个**用户的 `y_id`、`y_at`

[com_ah_with_zero_randomness](src/ppb.rs#L317)：`c1 = c.c0`、`c2 = 1`、`c3 = c.c1`、`c4 = 1`。
[wrap_ciphertext_for_cs_enc](src/ppb.rs#L356)：同样 `s1=s2=r1=r2=0`，`c1/c3` 就是原始密文分量。
而 `pi_id.c_enc` / `pi_at.c_enc` 正是这样包装的 `Enc(y_id; rid)` / `Enc(y_at; rat)`
（[src/ppb.rs:1737-1740](src/ppb.rs#L1737-L1740)）。

论文 Fig. 4.3 明确要求 `Com_QR(M) = (|M g^s|, (g')^s(h')^r)`，`s,r ←$ [2^{B+λ}]`。
后果：持有 `sk_E` 的审计者对 `CsCiphertext{c0: pi_id.c_enc.c1, c1: pi_id.c_enc.c3}`
直接 `dec_cs` 就得到 `y_id`——**对全体用户，包括不在名单上的**。Blueprint Hiding 彻底失效，
且不需要任何恶意行为。

### Z2 ✅ `E = Enc(P(y_id))` 明文随每份 escrow 发布 ⇒ 离线字典攻击

`PoKTranscript.c_p` 是 `pub` 字段（[src/pok.rs:194](src/pok.rs#L194)），
经 `PoKPProof.tau` → `PpbUserProof.pi_poly` → `PpbEscrowOutput.pi_u` 公开。
`E` 是公开数据的确定性函数（Horner 求值，无随机化），所以任何持 `pk_A` 的旁观者
对候选 `y*` 算 `∏A_i^{(y*)^i}` 与之比对即可定位 `y_id`。

### Z3 ✅ Remark 1 未实现：`y^{2^i}` / `y^{n/2}` 是**未约简的整数**

[src/pok.rs:1155](src/pok.rs#L1155)：`let z2 = &prev_z * &prev_z;` —— 全文件无 `% n`。
[pow_scalar_usize](src/pok.rs#L350)：精确整数幂。
于是 aux 第 i 项的见证是 `2^i·ℓ_N` 位的整数，而 Σ 协议掩码只有约 `4ℓ_N` 位
⇒ 从 `y^8`（aux round 3）起掩码就不够，`z_z = k_z + e·z` 可直接反解出 `z`，进而开方得 `y_id`。
论文 Remark 1 正是为此要求"指数证明必须附带 mod n 运算证明"。

**这一条同时是 ZK 破绽和实验失真源，见 §4。**

---

## 4. 对实验的影响（这一节直接改变实验方案）

### 4.1 好消息

死代码不是漏掉的验证工作，活验证器一个检查都不少。所以"VerEscrow/Judge 被低估"这条
最初的担忧不成立。

### 4.2 坏消息：aux 链本该是 O(log n)，现在是 O(n) —— 已实测

用 crate 的公开 API（`commit_df` / `prove_mult` / `verify_mult`）原样复现 aux 平方链，
对比"现状"与"Remark 1 合规版"（所有标量有界：`|w| ≤ 2ℓ_N`、`|k| ≤ ℓ_N`）：

```
ℓ_N   系数个数  轮数 |  现状 prove   现状 verify   最大见证    | 合规 prove  合规 verify | 倍率
512      128     7  |     244.1 ms     139.7 ms     65,020 bit |    92.5 ms     52.5 ms |   2.6× /  2.7×
512     1024    10  |    1700.2 ms    1046.6 ms    520,386 bit |   124.6 ms     62.8 ms |  13.6× / 16.7×
512     4096    12  |    6362.3 ms    3718.2 ms  2,090,607 bit |   153.4 ms     83.4 ms |  41.5× / 44.6×
512    16384    14  |   27464.1 ms   14937.3 ms  8,381,664 bit |   204.6 ms     84.0 ms | 134.3× /177.8×
1024    1024    10  |   12285.4 ms    7099.6 ms  1,047,473 bit |   923.2 ms    436.5 ms |  13.3× / 16.3×
1024    4096    12  |   52625.6 ms   31924.2 ms  4,188,330 bit |  1150.5 ms    538.8 ms |  45.7× / 59.2×
```

两条曲线的**形状完全不同**：
- 合规版 = `92.5 → 124.6 → 153.4 → 204.6`，每轮约 **12.8 ms**，即严格 **O(log n)**；
- 现状 = `244 → 1700 → 6362 → 27464`，系数个数翻倍它就翻倍，即 **O(n)**。

这正是论文的核心卖点被实现抹掉了：succinct 证明系统里唯一该是对数的那部分，
现在是线性的。在目标规模 `n=16383` 下最大见证是 **8,381,664 bit ≈ 1 MB 的整数**。

**占比**（ℓ_N=512, n=16383，Escrow 总计约 56.0 s / VerEscrow 约 30.4 s）：
aux 链 prove 27.5 s ≈ **49%**，verify 14.9 s ≈ **49%**。

而且它随 ℓ_N 的增长比协议其余部分**更快**（实测 512→1024 每翻倍 ×7.2–8.3，
协议整体只有 ×6.63），所以在 ℓ_N=4096 下占比只会更高。
外推 `ℓ_N=4096, n=16383`：aux 链约 3.6 h，其余约 2.3 h ⇒ **Escrow 里约 61% 是这个 bug**。

修掉之后，§3.3 的耗时表大约能砍到 **四成**。

### 4.3 但这不是"两行改动"——已验证

我原以为把 [src/pok.rs:1155](src/pok.rs#L1155) 改成取模就行。不成立：
[prove_mult_with_lambda](src/pok.rs#L685-L693) 校验的是**整数**关系
`C_out == g^{z·z}·h^{r}`，承诺 `z² mod n` 会让它直接返回 `Err`。
这正是论文写 Remark 1 的原因。

**标量侧的修法我已经写出来并跑通了**（上表 "合规" 列就是它）：
每轮把 `w = z²` 拆成 `w = z' + k·n`，并**刻意**取承诺随机数 `ρ_w = r_next + n·ρ_k`，
于是

```
C_w == C_next · C_k^n   (mod n²)
```

成为一个**代数恒等式**，验证方只需一次以 `n` 为指数的 modpow，不需要任何额外 Σ 协议。
（完整可靠性还需要对 `z' < n` 的范围证明；但当前实现连约简都没有，
所以不加范围证明也不构成回退。）

### 4.4 根因：Horner 求值与折叠证明结构不匹配

递归到底要求什么？设第 ℓ 层有 m 个系数 `C_j`，该层的值写成 `e = Π C_j^{u_j}`。
三条被证明的关系 `e = e1·e2`、`e2 = e3^{s}`、`e' = e1·e3^{α}` 展开后比对指数
（`c` 之间无已知关系），得到：

```
v_j = w_j = u'_j          (u' = 下一层的指数向量)
u_j        = u'_j          (j < m/2)
u_{j+m/2}  = u'_j · s      ← 整数乘法
```

递归基 `u^{(L)}_0 = 1`，自底向上展开即 **`u_i = Π_{k ∈ bits(i)} s_k`**。

注意：递归**只**要求 `u_{j+m/2} = u'_j · s` 这个整数等式，它并不要求
`s_k` 等于精确整数幂 `y^{2^k}`。

**真正强制精确整数幂的是 [`CiphertextPolynomial::evaluate`](src/pok.rs#L98-L113)。**
它用 Horner：`acc = acc^y · c_{i}`，展开就是 `E = Π c_i^{y^i}`，指数是精确整数幂。
而递归给出的是 `u_i = Π_{k∈bits(i)} s_k`。要让两者相等就只能 `s_k = y^{2^k}` 精确成立
——于是 aux 链被迫扛精确整数幂。

**Horner 是线性链，证明是二叉树，两者结构不同**；代码靠"精确整数幂"这个巧合把它们对上，
代价就是标量按 `2^k` 爆炸。

> 更正：本文档上一版写的"递归结构在群层面强制要求精确整数幂"是错的。
> 强制它的是求值写法，不是递归结构。

### 4.5 修法：用同一个折叠结构求值（已实测验证）

取 `ŝ_k = y^{2^k} mod n`（全部 ≤ ℓ_N 位），定义 `u_i = Π_{k∈bits(i)} ŝ_k`，则

```
u_{j+m/2} = u_j · ŝ_{log m − 1}            整数等式 ✓
e2 = e3^{ŝ}                                 精确成立，无需任何修正因子 ✓
e' = e1·e3^α = Π (C_j · C_{j+m/2}^α)^{u_j}  与下一层定义一致 ✓
base: u_0 = 1, e = C^{(L)}_0                就是验证方自己折出来的值 ✓
```

而 `E = Π c_i^{u_i}` 按同样的二叉折叠计算，代价与 Horner **完全相同**
（n 次 ℓ_N 位指数的 modexp），且证明者每层需要的 `e1 = fold(下半)`、`e3 = fold(上半)`
也由同一套折叠得到，全程不需要显式构造 `u_i`：

```
vec = c;  for k = L−1 down to 0:  vec[j] ← vec[j] · vec[j+m/2]^{ŝ_k}
```

因为 `u_i ≡ y^i (mod n)`，`HECdec` 解出的明文不变，方案语义不受影响。

**实测验证**（`probe fold`，三组参数全部通过）：

```
ℓ_N=256 coeffs= 16: max|ŝ_k|=255 bit (现状 4,096 bit)   max|u_i|=1014 bit
ℓ_N=256 coeffs= 64: max|ŝ_k|=254 bit (现状 16,320 bit)  max|u_i|=1513 bit
ℓ_N=512 coeffs=256: max|ŝ_k|=512 bit (现状 131,072 bit) max|u_i|=4090 bit

E_fold == E_direct            : true
每层 e2 == e3^(ŝ_k)           : true   ← 正是 verify_cs_mult 要的关系
dec(E_fold) == Σ x_i y^i mod n: true
dec(E_horner) == 同一明文     : true
E_fold 与 E_horner 群元素相同 : false  ← 不同密文、同一明文，符合预期
```

在目标规模 `ℓ_N=4096, coeffs=16384`：现状最大见证 `16384×4096 = 67,108,864` bit，
修完是 `4096` bit——**小 16384 倍**。

### 4.6 已实施，受控 A/B 结果

改动已落地（`pok.rs` / `ppb.rs` / `hec.rs`），76 个 lib 测试 + 4 个集成测试全绿。
用 `git stash` 做的受控 A/B（同一会话、ℓ_N=512、**满位长随机 y_id**、各 2 次取均值）：

| n=1023 | 改前 | 改后 | Δ |
|---|---|---|---|
| KeyGen | 5339 ms | 5171 ms | −3%（不走 PoKP，属噪声） |
| VerPK | 845 ms | 798 ms | −6%（不走 PoKP） |
| **Escrow** | **11497 ms** | **6119 ms** | **−46.8%** |
| **VerEscrow** | **6307 ms** | **2177 ms** | **−65.5%** |
| **Dec** | **6259 ms** | **2237 ms** | **−64.3%** |
| **Judge** | **7055 ms** | **2916 ms** | **−58.7%** |

更关键的是**斜率**（每个名单项的边际代价，由 n=127 与 n=1023 两点求得）：

| ms / 名单项 | 改前 | 改后 | Δ |
|---|---|---|---|
| Escrow | 10.08 | 4.67 | **−54%** |
| VerEscrow | 5.49 | 1.45 | **−74%** |
| Judge | 6.15 | 2.15 | **−65%** |

外推到目标规模 n=16383：Escrow 166 s → **78 s**，VerEscrow 91 s → **24 s**，
Judge 102 s → **36 s**（均为 ℓ_N=512；ℓ_N=4096 再乘位长因子）。

### 4.7 【方法学教训】退化的测试输入掩盖了这个 bug

第一次 A/B 我测出 Escrow **变慢 38%**，差点得出"修复是回退"的错误结论。
原因是探针的名单取 `3, 5, 7, …`，于是 `y_id = 3`：

- Horner 求值的指数是 `y = 3`，只有 **2 bit**，modexp 近乎免费；
- 精确整数幂 `y^{2^k} = 3^{1024}` 只有约 1623 bit，而不是 `2^k·ℓ_N = 524288` bit。

也就是说，**未约简标量的全部代价都被这个退化输入抵消了**，
折叠版反而因为要用满位长的 `ŝ_k` 而显得更慢。

仓库里原有的测试同样全部使用 5/11/13 这类小整数——这正是最初的实现
能通过全部测试的原因。已新增 `test_ppb_system_full_flow_with_full_size_inputs`
与 `pok.rs` 中的 `folded_eval_fixture` 系列，强制使用 `Z_n` 中的满位长随机值。

**推论：`EXPERIMENT_PLAN.md` §3.2/§3.3 早先那套代价模型全部作废**，
它们都是用 `y_id=3` 测出来的，严重低估真实代价。已重测。

### 4.8 顺带发现：`y_id + y_at < n` 是硬约束

用满位长随机输入时，`escrow_ppb` 有约 1/2 概率直接报
`C_y must equal C_id * C_at (mod n^2)`。原因：
[map_y_to_df_message](src/ppb.rs#L1460) 算的是 `m_y = (y_id+y_at) mod n`，
而验证侧比对的 `C_id · C_at = Com(y_id + y_at)` 用的是**整数和**，
两者只在 `y_id + y_at < n` 时相等。这是既有实现的限制（与 §3 的 S2 同源），
不是本次改动引入的。基准测试里把两者都约束到 `[0, n/2)` 规避。

### 4.9 具体改动清单

| # | 位置 | 改动 |
|---|---|---|
| 1 | [`CiphertextPolynomial::evaluate`](src/pok.rs#L98) | Horner → 二叉折叠，入参从 `y` 改为 `ŝ_0..ŝ_{L-1}`；顺带产出每层的 `e1/e3`，`pok_star_p` 不必重算 |
| 2 | [`pok.rs:1155`](src/pok.rs#L1155) | `z2 = &prev_z * &prev_z` → `w = z²`、`z' = w mod n`、`k = w / n`；`PoKAuxEntry` 增加 `c_w`、`c_k` 两个承诺 |
| 3 | 验证侧 [`ppb.rs:2277-2287`](src/ppb.rs#L2277) | 增加 Remark 1 归约检查 `C_w == C_next · C_k^n (mod n²)`——取 `ρ_w = r_next + n·ρ_k` 后它是代数恒等式，只需一次以 `n` 为指数的 modpow，**不需要额外 Σ 协议**（已跑通） |
| 4 | [`pow_scalar_usize`](src/pok.rs#L350) | 删除；`y^{half}` 直接从 aux 链读 `ŝ_k` |
| 5 | [`hec_eval`](src/hec.rs#L304) / [`build_poks2_proof`](src/ppb.rs#L1688) | 改用同一个折叠求值，保证 `E` 与证明链一致 |

验证方的折叠（[`ppb.rs:2221-2224`](src/ppb.rs#L2221)）**不用动**——它本来就是折叠结构。
改完之后证明者和验证者用的是同一套结构，而不是靠精确整数幂勉强对齐。

完整可靠性还需要对 `z' < n` 的范围证明；当前实现连约简都没有，所以不加也不构成回退。

---

## 5. 建议（按优先级）

1. **按 §4.6 把求值改成折叠结构 + aux 链模 n 约简**。
   一举关掉 Z3、把 aux 链从 O(n) 拉回 O(log n)、并让 Escrow/VerEscrow/Judge
   降约 50–60%。**在跑正式基准之前必须做。**
   顺带把 `prove_mult_with_lambda`（src/pok.rs:704）的掩码宽度对齐
   `prove_cs_mult` 的 `+256` 挑战余量（src/cs_commit.rs:175）。
2. **修 S1**：`verify_cs_com` 增加 `gcd(c1,n²)==1 && gcd(c3,n²)==1`；
   `verify_cs_mult` 拒绝非单位的 `cb.c1/cb.c3` 与 `proof.r1/r3`。
   仓库里已有现成的 [is_unit_mod_n2](src/ppb.rs#L990)（目前只被 PoKS3 用）。
3. **修 S2**：`C_y` 改为对 `(y_id, y_at)` 的向量承诺（`commit_df_multibase` / `commit_df_vector_with_bases`），
   删掉 `map_y_to_df_message`，按 Alg. 3 L10 补真正的 `π_y`。
4. **修 S3**：落实 `src/ppb.rs:2656-2667` 的 TODO，并约束 `r1`（当前完全自由，是攻击链第二环）。
5. **修 Z1**：给两个 wrapper 加上 Fig. 4.3 规定的真实盲化。
6. **修 Z2**：`CP ← Com_AH(cP; r_P)`，`r_P` 作为见证，从 `PoKTranscript` 移除 `c_p`。
   工作量最大——当前的 soundness 论证依赖求值链的公开可重算性。
7. **卫生**：删除 `verify_pok_star_recursive` / `verify_pokp_proof`，或移入 `#[cfg(test)]` 并改名。

---

## 6. 一个方法学提醒

第 2–7 项都会**增加**验证工作量，第 1 项会**减少**。所以在动手修之前测出来的数，
和修完之后测出来的数，不是同一个东西。表格里应当写清楚测的是哪个版本。

我个人建议：**只修第 1 项（以及第 2 项，开销可忽略）就去测**，
因为第 1 项修的是"实现把标量搞大了"，第 2 项修的是"漏了一个 O(1) 检查"，
两者都不改变方案的渐进代价；而 3–6 项是补齐论文要求的额外证明，
会让 Griffy 的数字变大——那属于"把方案实现完整"的工作，是否纳入取决于你要对比的是
"论文方案的真实代价"还是"这份代码的当前代价"。这个口径必须在论文里说清楚。
